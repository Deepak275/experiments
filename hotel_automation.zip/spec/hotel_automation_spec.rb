RSpec.describe HotelAutomation do
  it "has a version number" do
    expect(HotelAutomation::VERSION).not_to be nil
  end

  it "does something useful" do
  end
end
